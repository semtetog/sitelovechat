    <script src="/lovechat/assets/js/main.js"></script>
    <?php if(basename($_SERVER['PHP_SELF']) == 'index.php'): ?>
        <script src="/lovechat/login/js/script.js"></script>
    <?php else: ?>
        <script src="/lovechat/dashboard/js/script.js"></script>
    <?php endif; ?>
</body>
</html>